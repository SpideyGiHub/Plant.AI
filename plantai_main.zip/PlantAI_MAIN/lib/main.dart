import 'package:flutter/material.dart';
import 'package:plantai_main/splashscreen_welcome_login_signup.dart';
import 'package:plantai_main/homepage.dart';
import 'package:plantai_main/profile.dart';
import 'package:plantai_main/settingscreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const SplashScreen(


    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Implement the UI elements of the home page here
    return const Text('Home Page');
  }
}
