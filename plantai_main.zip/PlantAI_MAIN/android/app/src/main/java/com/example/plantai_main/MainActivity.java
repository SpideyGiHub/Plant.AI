package com.example.plantai_main;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
